# learn_AI
learning and test Ai codes
